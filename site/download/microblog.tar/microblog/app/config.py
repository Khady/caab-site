SQLALCHEMY_DATABASE_URI = 'sqlite:///microblog.db'
CSRF_ENABLED = True
SECRET_KEY = 'you-will-never-guess'
