from flask.ext.wtf import Form, TextField, PasswordField, TextAreaField, SubmitField
from flask.ext.wtf import Required, validators

class LoginForm(Form):
    login = TextField('Login', validators = [Required()])
    password = PasswordField('Password', validators = [Required()])
    submit = SubmitField('Submit',  validators = [Required()])

class AddBilletsForm(Form):
    titre = TextField('Titre', validators = [Required()])
    content = TextAreaField('Content', validators = [Required()])
    submit = SubmitField('Submit',  validators = [Required()])
