from app import db

class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    login = db.Column(db.Text)
    password = db.Column(db.Text)

    def __init__(self, login, password):
        self.login = login
        self.password = password

    def __repr__(self):
        return "<Users name %r>" % (self.login)

class Billets(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.Text)
    content = db.Column(db.Text)
    auteur = db.Column(db.Text)

    def __init__(self, titre, content, auteur):
        self.titre = titre
        self.content = content
        self.auteur = auteur

    def __repr__(self):
        return "<Billets name %r>" % (self.titre)
