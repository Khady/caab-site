from flask import render_template, session, redirect, url_for, flash
from app import app, db
from dbUtils import Billets, Users
from forms import LoginForm, AddBilletsForm
from functools import wraps

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in  session:
            session.pop("logged_in", None)
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def login_must_not_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' in  session:
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorated_function

@app.route("/")
def index():
    data = Billets.query.order_by(Billets.id).all()
    return render_template("index.html", data=data)

@app.route("/login", methods = ['GET', 'POST'])
@login_must_not_required
def login():
    form = LoginForm()
    if form.validate_on_submit():
        u = Users.query.filter_by(login=form.login.data).all()
        if len(u) != 0 and u[0].password == form.password.data:
            session['logged_in'] = True
            session['user_login'] = form.login.data
            flash("OMG CONNEXION SUCCESS !!!")
            return redirect(url_for("index"))
        flash("OMG NAAB !!!")
    return render_template("login.html", form=form)

@app.route("/addBillets", methods = ['GET', 'POST'])
@login_required
def addBillets():
    form = AddBilletsForm()
    if form.validate_on_submit():
        u = Billets(form.titre.data, form.content.data, session['user_login'])
        db.session.add(u)
        db.session.commit()
        return redirect(url_for("index"))
    return render_template("addBillets.html", form=form)

@app.route("/deco")
@login_required
def deco():
    session.pop('logged_in', None)
    flash("OMG DECO SUCCESS !!!")
    return redirect(url_for("index"))
